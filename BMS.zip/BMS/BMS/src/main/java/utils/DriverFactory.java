package utils;

import java.time.Duration;
import java.util.Scanner;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

// Utility class to launch and quit the WebDriver
public class DriverFactory {

    // Shared WebDriver instance
    private static WebDriver driver;

    // Asks the user to choose a browser at runtime and launches it
    public static WebDriver getDriver(String browser) {

        // Ask the user to choose a browser at runtime
        Scanner scanner = new Scanner(System.in);
        System.out.println("  Select Browser to Launch:");
        System.out.println("  1 -> Google Chrome");
        System.out.println("  2 -> Microsoft Edge");
        System.out.print("  Enter your choice (1 / 2): ");
        String userChoice = scanner.nextLine().trim();
        scanner.close();

        // Launch browser based on user's choice
        switch (userChoice) {

            case "1":
                // Launch Google Chrome with notifications disabled
                System.out.println("  Launching Google Chrome...");
                ChromeOptions chromeOptions = new ChromeOptions();
                driver = new ChromeDriver(chromeOptions);
                break;

            case "2":
                // Launch Microsoft Edge with notifications disabled
                System.out.println("  Launching Microsoft Edge...");
                EdgeOptions edgeOptions = new EdgeOptions();
                driver = new EdgeDriver(edgeOptions);
                break;

            default:
                // Invalid input — fall back to Google Chrome
                System.out.println("  Invalid choice entered. Defaulting to Google Chrome...");
                ChromeOptions chromeOptions1 = new ChromeOptions();
                driver = new ChromeDriver(chromeOptions1);
                break;
        }

        // Maximize the browser window
        driver.manage().window().maximize();

        // Implicit wait applied once after browser launch
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        return driver;
    }

    // Quits the browser and ends the WebDriver session
    public static void quitDriver() {
        if (driver != null) {
            driver.quit();
        }
    }
}