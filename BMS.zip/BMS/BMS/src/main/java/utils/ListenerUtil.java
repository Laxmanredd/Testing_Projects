package utils;
 
import org.testng.ITestListener;
import org.testng.ITestResult;
 
// TestNG Listener — automatically logs pass/fail to Extent Report
public class ListenerUtil implements ITestListener {
 
    // Logs test name as INFO when test passes
    @Override
    public void onTestSuccess(ITestResult result) {
        Extentreport.test.info("TEST PASSED-> " + result.getName());
    }
 
    // Logs test name as INFO and attaches failure screenshot when test fails
    @Override
    public void onTestFailure(ITestResult result) {
        Extentreport.test.info("TEST FAILED-> " + result.getName());
        Extentreport.test.addScreenCaptureFromPath(ScreenshotUtil.getfailScreenshotpath(result.getName()));
    }
}
